# Backend Takehome Project  
This project fetches research papers from the PubMed API.  
